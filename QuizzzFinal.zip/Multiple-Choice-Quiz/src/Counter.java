class Counter {
int M,S,Ms;

    Counter() {
       M=0;S=0;Ms=0; 
    }
}